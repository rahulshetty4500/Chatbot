'use client'

import { ChatInterface } from '@/components/chat/chat-interface'
import { Sidebar } from '@/components/chat/sidebar'
import { MoonIcon, SunIcon } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useTheme } from '@/hooks/use-theme'
import { MobileSidebar } from '@/components/chat/mobile-sidebar'

export default function Home() {
  const { theme, toggleTheme } = useTheme()

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Desktop Sidebar */}
      <div className="hidden md:block w-64 flex-shrink-0 h-full border-r">
        <Sidebar className="h-full" />
        <div className="p-4 border-t">
          <div className="flex items-center justify-between">
            <span className="text-sm">Theme</span>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleTheme}
              aria-label={theme === 'dark' ? "Switch to light mode" : "Switch to dark mode"}
              className="touch-target"
            >
              {theme === 'dark' ? (
                <SunIcon className="h-5 w-5" />
              ) : (
                <MoonIcon className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Mobile header with sidebar toggle and theme toggle */}
        <div className="md:hidden flex items-center justify-between p-4 border-b">
          <div className="flex items-center">
            <MobileSidebar />
            <h2 className="text-lg font-semibold ml-2">Legal Assistant</h2>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={toggleTheme}
            aria-label={theme === 'dark' ? "Switch to light mode" : "Switch to dark mode"}
            className="touch-target"
          >
            {theme === 'dark' ? (
              <SunIcon className="h-5 w-5" />
            ) : (
              <MoonIcon className="h-5 w-5" />
            )}
          </Button>
        </div>
        
        {/* Chat interface */}
        <ChatInterface />
      </div>
    </div>
  )
}
