'use client'

import { useState } from 'react'
import { Menu } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet'
import { Sidebar } from '@/components/chat/sidebar'
import { useTheme } from '@/hooks/use-theme'

export function MobileSidebar() {
  const [open, setOpen] = useState(false)
  const { theme, toggleTheme } = useTheme()

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden touch-target">
          <Menu className="h-5 w-5" />
          <span className="sr-only">Toggle sidebar</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="p-0 w-72">
        <Sidebar className="h-full" />
        <div className="p-4 border-t">
          <div className="flex items-center justify-between">
            <span className="text-sm">Theme</span>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleTheme}
              className="touch-target"
            >
              {theme === 'dark' ? 'Light' : 'Dark'}
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
