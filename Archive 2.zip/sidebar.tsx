'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { PlusIcon, Settings, Trash2 } from 'lucide-react'
import { cn } from '@/lib/utils'

interface SidebarProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string
}

interface ChatSession {
  id: string
  title: string
  date: Date
  selected?: boolean
}

export function Sidebar({ className, ...props }: SidebarProps) {
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([
    {
      id: '1',
      title: 'Contract Review',
      date: new Date(2025, 2, 15),
      selected: true
    },
    {
      id: '2',
      title: 'Legal Advice',
      date: new Date(2025, 2, 14)
    },
    {
      id: '3',
      title: 'Case Analysis',
      date: new Date(2025, 2, 13)
    }
  ])

  const handleNewChat = () => {
    const newChat: ChatSession = {
      id: Date.now().toString(),
      title: 'New Chat',
      date: new Date(),
      selected: true
    }
    
    setChatSessions(prev => 
      prev.map(chat => ({ ...chat, selected: false }))
        .concat(newChat)
    )
  }

  const selectChat = (id: string) => {
    setChatSessions(prev => 
      prev.map(chat => ({
        ...chat,
        selected: chat.id === id
      }))
    )
  }

  const deleteChat = (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    setChatSessions(prev => {
      const filtered = prev.filter(chat => chat.id !== id)
      // If we deleted the selected chat, select the first one
      if (prev.find(chat => chat.id === id)?.selected && filtered.length > 0) {
        filtered[0].selected = true
      }
      return filtered
    })
  }

  return (
    <div className={cn("flex flex-col h-full", className)} {...props}>
      <div className="p-4 border-b">
        <h2 className="text-lg font-semibold">Legal Assistant</h2>
      </div>
      
      <div className="p-4">
        <Button 
          className="w-full justify-start" 
          onClick={handleNewChat}
        >
          <PlusIcon className="h-4 w-4 mr-2" />
          New Chat
        </Button>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-2">
          <h3 className="text-sm font-medium mb-2">Chat History</h3>
          {chatSessions.map(chat => (
            <div 
              key={chat.id}
              className={cn(
                "flex items-center justify-between p-2 rounded-md cursor-pointer hover:bg-accent group",
                chat.selected && "bg-accent"
              )}
              onClick={() => selectChat(chat.id)}
            >
              <div className="truncate">
                <div className="font-medium truncate">{chat.title}</div>
                <div className="text-xs text-muted-foreground">
                  {chat.date.toLocaleDateString()}
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="opacity-0 group-hover:opacity-100"
                onClick={(e) => deleteChat(chat.id, e)}
              >
                <Trash2 className="h-4 w-4" />
                <span className="sr-only">Delete</span>
              </Button>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}
