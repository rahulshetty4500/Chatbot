# Legal Chatbot Interface - API Integration Guide

## Overview
This document provides guidance on how to integrate your legal API with the chatbot interface.

## Key Integration Points

### 1. Chat Message Handling
The main integration point is in `src/components/chat/chat-interface.tsx` in the `handleSendMessage` function:

```typescript
const handleSendMessage = async () => {
  if (inputValue.trim() === '') return

  // Add user message
  const userMessage: Message = {
    id: Date.now().toString(),
    content: inputValue,
    role: 'user',
    timestamp: new Date()
  }
  
  setMessages(prev => [...prev, userMessage])
  setInputValue('')
  
  // Show typing indicator
  setIsTyping(true)
  
  try {
    // Replace this with your API call
    const response = await fetch('YOUR_API_ENDPOINT', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message: inputValue,
        // Include any other context needed by your API
      }),
    });
    
    const data = await response.json();
    
    // Add bot message with typing animation
    const botMessage: Message = {
      id: (Date.now() + 1).toString(),
      content: data.response, // Use the response from your API
      role: 'assistant',
      timestamp: new Date(),
      isTyping: true
    }
    
    setMessages(prev => [...prev, botMessage])
    setIsTyping(false)
    
    // Text reveal animation timing
    const contentLength = data.response.length;
    const typingSpeed = 20; // ms per character
    const totalTypingTime = contentLength * typingSpeed;
    
    // Remove typing animation after text is fully revealed
    setTimeout(() => {
      setMessages(prev => 
        prev.map(msg => 
          msg.id === botMessage.id 
            ? { ...msg, isTyping: false } 
            : msg
        )
      )
    }, totalTypingTime);
  } catch (error) {
    console.error('Error fetching response:', error);
    
    // Handle error case
    const errorMessage: Message = {
      id: (Date.now() + 1).toString(),
      content: "Sorry, I encountered an error processing your request. Please try again.",
      role: 'assistant',
      timestamp: new Date()
    }
    
    setMessages(prev => [...prev, errorMessage])
    setIsTyping(false)
  }
}
```

### 2. PDF Document Handling
For PDF document uploads, modify the `handleFileSelect` function:

```typescript
const handleFileSelect = async (file: File) => {
  setUploadedFile(file)
  
  // Add a message about the uploaded file
  const userMessage: Message = {
    id: Date.now().toString(),
    content: `Uploaded document: ${file.name}`,
    role: 'user',
    timestamp: new Date()
  }
  
  setMessages(prev => [...prev, userMessage])
  setIsTyping(true)
  
  try {
    // Create a FormData object to send the file
    const formData = new FormData();
    formData.append('file', file);
    
    // Send the file to your API
    const response = await fetch('YOUR_API_DOCUMENT_ENDPOINT', {
      method: 'POST',
      body: formData,
    });
    
    const data = await response.json();
    
    // Add bot message with the response
    const botMessage: Message = {
      id: (Date.now() + 1).toString(),
      content: data.response, // Use the response from your API
      role: 'assistant',
      timestamp: new Date(),
      isTyping: true
    }
    
    setMessages(prev => [...prev, botMessage])
    setIsTyping(false)
    
    // Text reveal animation timing
    const contentLength = data.response.length;
    const typingSpeed = 20;
    const totalTypingTime = contentLength * typingSpeed;
    
    setTimeout(() => {
      setMessages(prev => 
        prev.map(msg => 
          msg.id === botMessage.id 
            ? { ...msg, isTyping: false } 
            : msg
        )
      )
    }, totalTypingTime);
  } catch (error) {
    console.error('Error processing document:', error);
    
    // Handle error case
    const errorMessage: Message = {
      id: (Date.now() + 1).toString(),
      content: "Sorry, I encountered an error processing your document. Please try again.",
      role: 'assistant',
      timestamp: new Date()
    }
    
    setMessages(prev => [...prev, errorMessage])
    setIsTyping(false)
  }
}
```

### 3. Chat History Integration
To integrate with a backend for chat history persistence, modify the sidebar component:

```typescript
// In src/components/chat/sidebar.tsx

// Add a useEffect to fetch chat history
useEffect(() => {
  const fetchChatHistory = async () => {
    try {
      const response = await fetch('YOUR_API_HISTORY_ENDPOINT');
      const data = await response.json();
      setChatSessions(data.sessions);
    } catch (error) {
      console.error('Error fetching chat history:', error);
    }
  };
  
  fetchChatHistory();
}, []);

// Update handleNewChat to create a session on the backend
const handleNewChat = async () => {
  try {
    const response = await fetch('YOUR_API_NEW_CHAT_ENDPOINT', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        title: 'New Chat',
        date: new Date(),
      }),
    });
    
    const data = await response.json();
    
    const newChat: ChatSession = {
      id: data.id,
      title: data.title,
      date: new Date(data.date),
      selected: true
    }
    
    setChatSessions(prev => 
      prev.map(chat => ({ ...chat, selected: false }))
        .concat(newChat)
    )
  } catch (error) {
    console.error('Error creating new chat:', error);
  }
}
```

## Environment Configuration
Create a `.env.local` file in the project root with your API endpoints:

```
NEXT_PUBLIC_API_BASE_URL=https://your-api-base-url.com
NEXT_PUBLIC_API_CHAT_ENDPOINT=/api/chat
NEXT_PUBLIC_API_DOCUMENT_ENDPOINT=/api/document
NEXT_PUBLIC_API_HISTORY_ENDPOINT=/api/history
```

Then use these environment variables in your API calls:

```typescript
const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL;
const API_CHAT_ENDPOINT = process.env.NEXT_PUBLIC_API_CHAT_ENDPOINT;

// Example usage
const response = await fetch(`${API_BASE_URL}${API_CHAT_ENDPOINT}`, {
  // request options
});
```

## Authentication
If your API requires authentication, add an auth header to your fetch requests:

```typescript
const response = await fetch('YOUR_API_ENDPOINT', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${authToken}`, // Add your auth token here
  },
  body: JSON.stringify({
    message: inputValue,
  }),
});
```

## Deployment
For production deployment, build the application and deploy it to your hosting provider:

```bash
npm run build
```

The built files will be in the `.next` directory, ready for deployment.
