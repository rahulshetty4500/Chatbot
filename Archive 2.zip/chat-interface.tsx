'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Send } from 'lucide-react'
import { FileUpload } from '@/components/chat/file-upload'

interface Message {
  id: string
  content: string
  role: 'user' | 'assistant'
  timestamp: Date
  isTyping?: boolean
}

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Scroll to bottom whenever messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSendMessage = () => {
    if (inputValue.trim() === '') return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      role: 'user',
      timestamp: new Date()
    }
    
    setMessages(prev => [...prev, userMessage])
    setInputValue('')
    
    // Simulate bot typing
    setIsTyping(true)
    
    // Simulate bot response after delay
    setTimeout(() => {
      const botResponse = "This is a simulated response from the legal assistant. In a real implementation, this would connect to your API.";
      
      // Add bot message with typing animation
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: botResponse,
        role: 'assistant',
        timestamp: new Date(),
        isTyping: true
      }
      
      setMessages(prev => [...prev, botMessage])
      setIsTyping(false)
      
      // Simulate text reveal animation
      const contentLength = botResponse.length;
      const typingSpeed = 20; // ms per character
      const totalTypingTime = contentLength * typingSpeed;
      
      // Remove typing animation after text is fully revealed
      setTimeout(() => {
        setMessages(prev => 
          prev.map(msg => 
            msg.id === botMessage.id 
              ? { ...msg, isTyping: false } 
              : msg
          )
        )
      }, totalTypingTime);
    }, 1000)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handleFileSelect = (file: File) => {
    setUploadedFile(file)
    // Add a message about the uploaded file
    const userMessage: Message = {
      id: Date.now().toString(),
      content: `Uploaded document: ${file.name}`,
      role: 'user',
      timestamp: new Date()
    }
    
    setMessages(prev => [...prev, userMessage])
    
    // Simulate bot response about the document
    setIsTyping(true)
    setTimeout(() => {
      const botResponse = `I've received your document "${file.name}". What would you like to know about it?`;
      
      // Add bot message with typing animation
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: botResponse,
        role: 'assistant',
        timestamp: new Date(),
        isTyping: true
      }
      
      setMessages(prev => [...prev, botMessage])
      setIsTyping(false)
      
      // Simulate text reveal animation
      const contentLength = botResponse.length;
      const typingSpeed = 20; // ms per character
      const totalTypingTime = contentLength * typingSpeed;
      
      // Remove typing animation after text is fully revealed
      setTimeout(() => {
        setMessages(prev => 
          prev.map(msg => 
            msg.id === botMessage.id 
              ? { ...msg, isTyping: false } 
              : msg
          )
        )
      }, totalTypingTime);
    }, 1000)
  }

  // Function to render message content with typing animation
  const renderMessageContent = (message: Message) => {
    if (message.role === 'user' || !message.isTyping) {
      return <p>{message.content}</p>;
    }
    
    // For assistant messages with typing animation
    return (
      <p className="text-reveal">
        {message.content.split('').map((char, index) => (
          <span 
            key={index} 
            className="text-reveal-content"
            style={{ animationDelay: `${index * 20}ms` }}
          >
            {char}
          </span>
        ))}
      </p>
    );
  };

  return (
    <div className="flex flex-col h-screen">
      {/* Messages area */}
      <ScrollArea className="flex-1 p-4 chat-container">
        <div className="space-y-4 max-w-3xl mx-auto messages-container">
          {messages.length === 0 ? (
            <div className="text-center text-muted-foreground py-8">
              <h3 className="text-lg font-medium">Welcome to Legal Assistant</h3>
              <p className="mt-2">Ask any legal question to get started</p>
            </div>
          ) : (
            messages.map(message => (
              <div
                key={message.id}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} mb-3`}
              >
                <div
                  className={`message-bubble ${message.role === 'user' ? 'user' : 'assistant'}`}
                >
                  {renderMessageContent(message)}
                  <div className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            ))
          )}
          
          {isTyping && (
            <div className="flex justify-start mb-3">
              <div className="message-bubble assistant">
                <div className="typing-animation-container">
                  <div className="typing-animation">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>
      
      {/* Input area */}
      <Card className="mx-4 mb-4 border input-area">
        <div className="flex items-center p-2 input-container">
          <FileUpload 
            onFileSelect={handleFileSelect}
            className="mr-2 touch-target"
          />
          
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message..."
            className="flex-1"
          />
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="ml-2 touch-target"
            onClick={handleSendMessage}
            disabled={inputValue.trim() === ''}
          >
            <Send className="h-5 w-5" />
            <span className="sr-only">Send message</span>
          </Button>
        </div>
      </Card>
    </div>
  )
}
